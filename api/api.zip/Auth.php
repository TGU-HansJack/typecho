<?php
class Auth {
    public static function check(): bool {
        $cfg = $GLOBALS['__API_CONFIG__'];
        if (empty($cfg['REQUIRE_AUTH'])) return true;

        $auth = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
        if (stripos($auth, 'Bearer ') !== 0) return false;
        $token = trim(substr($auth, 7));
        return $token === $cfg['API_KEY'];
    }

    public static function require() {
        if (!self::check()) {
            Response::json(['error' => 'Unauthorized'], 401);
        }
    }
}
