<?php
return [
    // 是否启用鉴权：true 时必须携带 Bearer Token
    'REQUIRE_AUTH' => true,

    // 简易 API Key（Bearer <API_KEY>）
    'API_KEY' => 'change_this_to_a_strong_secret',

    // 允许的跨域源（* 表示全开放，生产建议精确到你的域名）
    'CORS_ALLOW_ORIGIN' => '*',

    // 分页默认值
    'PAGINATION' => [
        'perPage' => 10,
        'maxPerPage' => 100,
    ],
    
    // 请求频率限制
    'RATE_LIMIT' => [
        'enabled' => true,
        'requests' => 100,  // 每个时间窗口的请求数
        'window' => 3600    // 时间窗口（秒）
    ],
    
    // JWT配置
    'JWT' => [
        'lifetime' => 86400 // 令牌有效期（秒）
    ]
];