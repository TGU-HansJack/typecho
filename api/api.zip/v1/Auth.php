<?php
class Auth {
    const TOKEN_LIFETIME = 86400; // 24小时
    
    public static function check(): bool {
        $cfg = $GLOBALS['__API_CONFIG__'];
        if (empty($cfg['REQUIRE_AUTH'])) return true;

        $auth = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
        if (stripos($auth, 'Bearer ') !== 0) return false;
        $token = trim(substr($auth, 7));
        
        // 首先检查是否为API密钥（向后兼容）
        if ($token === $cfg['API_KEY']) {
            return true;
        }
        
        // 检查是否为JWT令牌
        return self::validateToken($token);
    }
    
    public static function require() {
        if (!self::check()) {
            Response::json(['error' => 'Unauthorized'], 401);
        }
    }
    
    public static function getUser(): ?array {
        $auth = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
        if (stripos($auth, 'Bearer ') !== 0) return null;
        $token = trim(substr($auth, 7));
        
        // 检查是否为JWT令牌
        $payload = self::decodeToken($token);
        if ($payload && isset($payload['uid'])) {
            $d = db();
            return $d->fetchRow($d->select()->from('table.users')->where('uid = ?', $payload['uid'])->limit(1));
        }
        
        return null;
    }
    
    public static function generateToken(int $uid): string {
        $header = base64_encode(json_encode(['typ' => 'JWT', 'alg' => 'HS256']));
        $payload = base64_encode(json_encode([
            'uid' => $uid,
            'exp' => time() + self::TOKEN_LIFETIME,
            'iat' => time()
        ]));
        
        $signature = base64_encode(hash_hmac('sha256', $header . '.' . $payload, $GLOBALS['__API_CONFIG__']['API_KEY'], true));
        
        return $header . '.' . $payload . '.' . $signature;
    }
    
    private static function validateToken(string $token): bool {
        $payload = self::decodeToken($token);
        return $payload !== null && (!isset($payload['exp']) || $payload['exp'] > time());
    }
    
    private static function decodeToken(string $token): ?array {
        $parts = explode('.', $token);
        if (count($parts) !== 3) return null;
        
        [$header, $payload, $signature] = $parts;
        
        $expectedSignature = base64_encode(hash_hmac('sha256', $header . '.' . $payload, $GLOBALS['__API_CONFIG__']['API_KEY'], true));
        if ($signature !== $expectedSignature) return null;
        
        $payloadData = json_decode(base64_decode($payload), true);
        return is_array($payloadData) ? $payloadData : null;
    }
}